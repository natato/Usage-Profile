class port_usage implements model{
	usage_modeller math_modeller;
	double usageVal;// a system's usage value at a point in time
	double x1; //time elapse during communication
	paired_ports x2; // details about paired ports including statistics bout port usage
	double y;// number of paied ports
	public double computeval(){
		return 0;
	}
	public double findchange(){
		return 0;
	}
	public void learnsys(int t){
		System.out.println("learning port usage ...");
	}
	public Object findrelationship(){
		return null;
	}
	public void monitor(int t){
	}
	public void showalarm(String info){
		System.out.println(info);
	}
	public void haltprocess(){
	}
	public void predictvals(){
	}
	protected class paired_ports{
	
	}
}