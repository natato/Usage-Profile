class x_set{
	double x_set[];
	int n;
	x_set(int n){
		this.n=n;
		x_set=new double[n];
	}
	void set_xset(double x_set[]){
		this.x_set=x_set;
	}
}