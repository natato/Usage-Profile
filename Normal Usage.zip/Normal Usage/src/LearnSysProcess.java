import java.util.*;
class LearnSysProcess extends Thread{
	String process_name;
	model usage;
	int time;
	int time2;
	int N;
	Thread process;
	LearnSysProcess(String name,model x, int t,int n,int t2){
		process_name=name;
		usage=x;
		time=t;	
		N=n;
		time2=t2;
	}
	public void run(){
		try{
			switch(N){
				case 1://learn system
					usage.learnsys(time);
				break;
				case 2:// find relationship
					usage.findrelationship();
				break;
				case 3:// monitor system
					usage.monitor(time2);
				break;
			}
			
		}
		catch(Exception e){
			
		}	
	}
	public void start(){
		if(process==null){
			process=new Thread(this,process_name);
			process.start();
			
		}
	}
}