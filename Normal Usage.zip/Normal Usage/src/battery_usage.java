class battery_usage implements model{
	boolean system_learning;
	usage_modeller math_modeller;
	double usageVal;// a system's usage value at a point in time
	cpu_usage x1;
	session_usage x2;
	memory_usage x3;
	public void set_memory_usage(memory_usage x3){
		this.x3=x3;
	}
	public void set_cpu_usage(cpu_usage x1){
		this.x1=x1;
	}
	public void set_session_usage(session_usage x2){
		this.x2=x2;
	}
	public double computeval(){
		return 0;
	}
	public double findchange(){
		return 0;
	}
	public void learnsys(int t){
		System.out.println("learning battery usage ...");
		x1.learnsys(t);
		x2.learnsys(t);
		x3.learnsys(t);
	}
	public Object findrelationship(){
		return null;
	}
	public void monitor(int t){
	}
	public void showalarm(String info){
	}
	public void haltprocess(){
	}
	public void predictvals(){
	}
}