class program_usage implements model{
	usage_modeller math_modeller;
	double usageVal;// a system's usage value at a point in time
	double x1;//number of functions
	double x2;// cpu time used
	double x3;//memory space used
	double c1;//max functions;
	double c2;// min functions
	public double computeval(){
		return 0;
	}
	public double findchange(){
		return 0;
	}
	public void learnsys(int t){
		System.out.println("learning program usage ...");
	}
	public Object findrelationship(){
		return null;
	}
	public void monitor(int t){
	}
	public void showalarm(String info){
		System.out.println(info);
	}
	public void haltprocess(){
	}
	public void predictvals(){
	}
}