class network_usage implements model{
	usage_modeller math_modeller;
	double usageVal;// a system's usage value at a point in time
	port_usage port_usag;
	server_usage server_usag;
	host_usage host_usag;// use device usage model for mobile hosts like phones and laptops
	double x1;//number of processes running on network
	double y1;// size of data transmitted
	double y2; // how long network operates
	network_usage(){
		port_usag=new port_usage();
		server_usag=new server_usage();
		host_usag=new host_usage();
	}
	public void set_port_usage(port_usage port_usag){
		this.port_usag=port_usag;
	}
	public void set_host_usage(host_usage host_usag){
		this.host_usag=host_usag;
	}
	public void set_server_usage(server_usage server_usag){
		this.server_usag=server_usag;
	}
	public double computeval(){
		return 0;
	}
	public double findchange(){
		return 0;
	}
	public void learnsys(int t){
		System.out.println("learning network usage ...");
		//port_usag.learnsys(t);
		//server_usag.learnsys(t);
		//host_usag.learnsys(t);
	}
	public Object findrelationship(){
		return null;
	}
	public void monitor(int t){
		port_usag.monitor(t);
		server_usag.monitor(t);
		host_usag.monitor(t);
	}
	public void showalarm(String info){
		System.out.println(info);
	}
	public void haltprocess(){
	}
	public void predictvals(){
	}
}