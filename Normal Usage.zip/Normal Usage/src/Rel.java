import java.util.*;
class Rel{
	public Fnx find_sim_lin_Rel(int sample_size,ArrayList<Float> x_list,ArrayList<Double>y_list){
		double sumX=0;
		double sumY=0;
		double sumXY=0;
		double sumX_square=0;
		double sumY_square=0;
		if(sample_size>0){
			for(int i=0;i<sample_size;i++){
				sumY=sumY+y_list.get(i);
				sumX=sumX+x_list.get(i);
				sumXY=sumXY+(y_list.get(i)*x_list.get(i));
				sumX_square=sumX_square+(Math.pow(x_list.get(i),2));
				sumY_square=sumY_square+(Math.pow(y_list.get(i),2));
			}
			double r=((sample_size*sumXY)-(sumX*sumY))/(Math.sqrt(((sample_size*sumX_square)-Math.pow(sumX,2))*((sample_size*sumY_square)-Math.pow(sumY,2))));
			double a=((sumY*sumX_square)-(sumX*sumXY))/((sample_size*sumX_square)-(Math.pow(sumX,2)));
			double b=((sample_size*sumXY)-(sumX*sumY))/((sample_size*sumX_square)-(Math.pow(sumX,2)));
			Fnx obj=new Fnx(a,b);
			obj.setR(r);
			return obj;
		}
		else{
			return null;
		}
	}
	public Fnx find_mult_lin_Rel(int sample_size,ArrayList<Float> x_list,ArrayList<Double>y_list){
	
		if(sample_size>0){
			for(int i=0;i<sample_size;i++){
				
			}
			Fnx obj=new Fnx(a,b);
			obj.setR(r);
			return obj;
		}
		else{
			return null;
		}
	}
	public Fnx find_non_lin_1__Rel(int sample_size,ArrayList<Float> x_list,ArrayList<Double>y_list){// for relations y2=x2/xy
	
		if(sample_size>0){
			for(int i=0;i<sample_size;i++){
				
			}
			Fnx obj=new Fnx(a,b);
			obj.setR(r);
			return obj;
		}
		else{
			return null;
		}
	}
}