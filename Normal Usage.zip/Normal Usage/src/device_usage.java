class device_usage extends host_usage{
	usage_modeller math_modeller;
	double usageVal;// a system's usage value at a point in time
	double y;// time spent on device
	battery_usage battery_usag;
	device_usage(){
		super();
		this.is_mobile=true;
		battery_usag=new battery_usage();
	}
	public double computeval(){
		return 0;
	}
	public double findchange(){
		return 0;
	}
	public void learnsys(int t){
		//battery_usag.learnsys(t);
		System.out.println("learning device usage ...");
	}
	public Object findrelationship(){
		return null;
	}
	public void monitor(int t){
	}
	public void showalarm(String info){
	}
	public void haltprocess(){
	}
	public void predictvals(){
	}
}