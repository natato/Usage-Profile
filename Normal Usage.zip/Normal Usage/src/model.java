public interface model{
public double computeval();
public double findchange();
public void learnsys(int t);
public Object findrelationship();
public void monitor(int t);
public void showalarm(String info);
public void haltprocess();
public void predictvals();
}